function NotFoundPage(params) {
    return(
        <div className="container-table">
            <h1>Page Not Found</h1>
        </div>
    )
 
}
export default NotFoundPage