import axios from 'axios'



export default {
    get : axios.get,
    post : axios.post,
    delete : axios.delete,
    put : axios.put,
}