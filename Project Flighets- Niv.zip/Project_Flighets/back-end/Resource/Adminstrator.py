
from flask_restful import Resource,reqparse
from models.Adminstrator import AdminstratorsModel
from Resource.security.user_login import  token_required


class Admin(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('first_name', type=str, required=True, help='Every users must have a name') 
    parser.add_argument('last_name', type=str, required=True, help='Every users must have a name') 
    parser.add_argument('user_id', type=int, required=True, help='Every users must have a name') 

    @token_required
    def get(self,id):
        admin = AdminstratorsModel.find_by_user_id(id)
        if admin:
            return {'admin':admin.json()},200
        return {'message':'Admin not found'},400

    @token_required
    def post(self):
        data = Admin.parser.parse_args()
        admin = AdminstratorsModel.find_by_user_id(data['user_id'])
        name = AdminstratorsModel.find_by_name(data['first_name'])
        if admin or name:
            return {'message':'Admin exists'},400
        admin = AdminstratorsModel(data['first_name'],data['last_name'],data['user_id'])
        admin.save_to_db()
        return {'message':'Admin created'},201
    
    @token_required
    def delete(self,id):
        admin =  AdminstratorsModel.find_by_user_id(id)
        if admin:
            admin.delete_from_db()
            return {'message':'Deleted'},202
        return {'message': 'admin not found'},400
        
    @token_required
    def put(self,name):
        data = Admin.parser.parse_args()
        admin =  AdminstratorsModel.find_by_name(name)
        if admin:
            admin.first_name = data['first_name']
            admin.last_name = data['last_name']
            admin.user_id = data['user_id']
            admin.Update() 
            return {'message':'Admin update'},200          
        return {'message': 'admin not found'},400

class Admins(Resource):
    @token_required
    def get(self):
        user = AdminstratorsModel.query.all()
        return {'ALL Admins':list(x.json() for x in user)},200