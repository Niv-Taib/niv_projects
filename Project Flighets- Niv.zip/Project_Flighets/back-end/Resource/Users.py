
from flask_restful import Resource,reqparse
from Resource.security.user_login import  token_required
from models.Users import UsersModel


class User(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument('username', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('password', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('email', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('user_roles_id', type=int, required=True, help="This field cannot be blank" )

    @token_required
    def get(self,username):
        user = UsersModel.find_by_username(username)
        if user:
           return {'user':user.json()},200 
        return {'message':'User does not exist'},400


    def post(self):
        data = User.parser.parse_args()
        if UsersModel.find_by_username(data['username']):
            return {'message':"A user whit that name already exists"},400
        UsersModel(data['username'],data['password'],data['email'],data['user_roles_id']).save_to_db()
        user = UsersModel.find_by_username(data['username'])
        return {'message':'Create user','id':user.id},201


    
    @token_required
    def delete(self,username):
        new_user =  UsersModel.find_by_username(username)
        if new_user:
            new_user.delete_from_db()
            return {'message':'Deleted successfully'},200
        return {'message': 'User does not exist'},400

    @token_required
    def put(self,username):
        data = User.parser.parse_args()
        user = UsersModel.find_by_username(username)
        if user:
            user.username = data['username']
            user.password= data['password']
            user.email= data['email']
            user.user_roles_id= data['user_roles_id']
            user.Update()
            return {'message':'Update user'},200
        return {'message': 'User does not exist'},400



        
class Users(Resource):
    @token_required
    def get(self):
        user = UsersModel.query.all()
        return {'all':list(x.json() for x in user)},200
    



