import jwt, datetime
from hmac import compare_digest
from Resource.security.common import falseReturn,trueReturn
from models.Adminstrator import AdminstratorsModel
from models.Airline_Companies import Airline_Companies_Model
from models.Users import UsersModel
from __init__ import Config

def chek_admin(user_id):
    if AdminstratorsModel.find_by_user_id(user_id):
        return True
    return False
def chek_airline(user_username):
    if Airline_Companies_Model.find_by_user_id(user_username):
        return True
    return False


class Auth():

    @staticmethod
    def encode_auth_token(user):
        try:
            payload ={
                "exp": datetime.datetime.utcnow() + datetime.timedelta(days=1, hours=0, minutes=0, seconds=0),
                "iat": datetime.datetime.utcnow(),
                "user_id" : user.id,
                "username" : user.username,
                "email" : user.email,
                "isAdmin": chek_admin(user.id),
                "isAirline": chek_airline(user.username),
                "isUser": True,
            }
            if payload['isAirline'] == True:
                airline = Airline_Companies_Model.find_by_user_id(user.username)
                if airline:
                    payload['Airline_name'] = airline.name
            signature = jwt.encode(payload,Config.app.secret_key, algorithm="HS256")
            return signature
        except Exception as e:
            return e

    @staticmethod
    def decode_auth_token(auth_token):
        try:
            payload = jwt.decode(auth_token,Config.app.secret_key, algorithms=["HS256"])
            if payload:
                return payload
            else:
                raise jwt.InvalidTokenError

        except jwt.ExpiredSignatureError:
            return 'Token Expired'
        except jwt.InvalidTokenError:
            return 'Invalid Token'

    @classmethod
    def authenticate(cls,username, password):
        user = UsersModel.find_by_username(username)
        if user and compare_digest(user.password, password):
            token = cls.encode_auth_token(user)
            return {"access_token": token.encode().decode('utf-8')}, 200
        else:
            return {"desciption": "Invalid credentials"
            , "status_code" : 401
            ,"error": "Bad Request"}, 401

    @classmethod
    def identity(token):
        try:
            if not token or token['headers']['typ'] != 'JWT':
                return falseReturn('', "Please pass correct auth token")

            payload = Auth.decode_auth_token(token)
            user = UsersModel.find_by_id(payload['payload']['user_id'])
            if user is None:
                return falseReturn('', "User information not found")
            else:
                return trueReturn(user.id, "request suceeseded")
        except jwt.ExpiredSignatureError:
            return 'Token Expired'
        except jwt.InvalidTokenError:
            return 'Invalid Token' 