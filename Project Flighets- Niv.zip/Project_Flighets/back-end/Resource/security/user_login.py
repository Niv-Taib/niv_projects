from flask_restful import Resource, reqparse
from flask import  request, make_response
from flask import jsonify
from Resource.security.auth import  Auth
from models.Users import UsersModel
from functools import wraps

def token_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):
        token = None
        if 'x-auth-token' in request.headers:
            token = request.headers['x-auth-token']
            token = token.replace('"',"")
        if not token:
            return make_response(jsonify({"message": "A valid token missing"}), 401)        
        try:
            data = Auth.decode_auth_token(token)
            current_user = UsersModel.find_by_id(data['user_id'])
        except:
            return make_response(jsonify({"message": "Invalid token"}), 401)

        return f(*args, **kwargs)
    return decorator


class User_Login(Resource):
    parser = reqparse.RequestParser()
    parser.add_argument('username', type=str, required=True, help="must have")
    parser.add_argument('password', type=str, required=True, help="must have")

    def post(self):
        data = User_Login.parser.parse_args()
        username = data['username']
        password = data['password']

        return Auth.authenticate(username, password)
