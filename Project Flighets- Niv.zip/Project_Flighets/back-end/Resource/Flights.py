

from flask_restful import Resource,reqparse
from models.Flights import FlightsModel
from Resource.security.user_login import  token_required


class Flight(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument('airline_company', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('origin_country', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('deistination_country', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('departure_time', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('lending_time', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('remaining_tickets', type=str, required=True, help="This field cannot be blank" )


    @token_required
    def get(self,id):
        Flight =FlightsModel.find_by_id(id)
        if Flight: 
            return {"Flight":Flight.json()},200
        return {'message': 'Flight not found'},404 

       
    @token_required
    def post(self):
        data = Flight.parser.parse_args()
        flight= FlightsModel(data['airline_company'],data['origin_country'],data['deistination_country'],
                                data['departure_time'],data['lending_time'],data['remaining_tickets'])
        if flight:
            flight.save_to_db()
            flight = FlightsModel.find_by_name(data['airline_company']).json()
            return {'message': 'Flight created',"flight":flight},201   
        return {'message': 'Flight not created'},400

    
    @token_required
    def put(self,id):
        data = Flight.parser.parse_args()
        flight =FlightsModel.find_by_id(id)
        if flight:
            flight.airline_company = data['airline_company']
            flight.origin_country = data['origin_country']
            flight.deistination_country= data['deistination_country'] 
            flight.departure_time = data['departure_time'] 
            flight.lending_time = data['lending_time'] 
            flight.remaining_tickets = data['remaining_tickets'] 
            flight.Update()
            return {'message':'Update flight'},200
        return {'message': 'Flight not found'},400 


    @token_required
    def delete(self,id):
        flight =  FlightsModel.find_by_id(id)
        if flight:
            flight.delete_from_db()
            return {'message':'Deleted'},200
        return {'message': 'Flight not found'},400
        

class Flights(Resource):    

    parser = reqparse.RequestParser()
    parser.add_argument('origin_country', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('deistination_country', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('departure_time', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('lending_time', type=str, required=True, help="This field cannot be blank" )

    
    def get(self):
        Flighets = list(x.json() for x in FlightsModel.query.all())
        return {'all':Flighets},200

