
from flask_restful import Resource,reqparse
from models.Tickets import TicketsModel
from models.Flights import FlightsModel
from Resource.security.user_login import  token_required

class Ticket(Resource):

    parser = reqparse.RequestParser()
    parser.add_argument('customer_id', type=int, required=True, help="This field cannot be blank" )
    parser.add_argument('flight_id', type=int, required=True, help="This field cannot be blank" )


    @token_required
    def get(self,id):
        Ticket = TicketsModel.find_by_customer_id(id)
        if Ticket:
                Ticket = list(x.json() for x in Ticket)
                return {'ticket': Ticket},200  
        return {'message': 'Ticket not found'},400

    @token_required
    def post(self):
        data = Ticket.parser.parse_args()
        ticket = TicketsModel(data['flight_id'],data['customer_id'])
        flight = FlightsModel.find_by_id(data['flight_id'])
        if flight:
            if int(flight.remaining_tickets) == 0:
                return {'message': 'No Ticket left'},400  
            flight.remaining_tickets = int(flight.remaining_tickets) -1
            flight.Update()
            ticket.save_to_db()
            ticket = TicketsModel.find_by_flight_id(data['flight_id']).json()
            return  {'message': 'Ticket Added successfully',"ticket":ticket},201
        return {'message': 'Flight not found '},400    

    @token_required
    def delete(self,id):
        Ticket = TicketsModel.find_by_id(id)
        if Ticket:
            Ticket.delete_from_db()
            return {'message':'Deleted'},200
        return {'message': 'Ticket not found'},400
        
    @token_required
    def put(self,id):
        data = Ticket.parser.parse_args()
        try:
            customer = TicketsModel.find_by_id(id).first()
            if customer:
                customer.customer_id = data['customer_id']
                customer.flight_id = data['flight_id']
                customer.Update()
                return {'customer':'Ticket updata'},200
        except:
            return {'customer':'Ticket not fond'},400


class Tickets(Resource):
    @token_required
    def get(self):
        tickets = TicketsModel.query.all()
        return {'all':list(x.json() for x in tickets)},200


