
from flask_restful import Resource,reqparse
from models.Customers import CustomersModel
from Resource.security.user_login import  token_required

class Customer(Resource):

    parser = reqparse.RequestParser()
    parser.add_argument('first_name', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('last_name', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('address', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('phone_no', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('credit_card_no', type=str, required=True, help="This field cannot be blank" )
    parser.add_argument('user_id', type=str, required=True, help="This field cannot be blank" )

    @token_required
    def get(self,id):
        customer = CustomersModel.find_by_id(id)
        if customer:
            return {'customer':customer.json() },200
        return {'message':"customer Not exist"},400


    def post(self):
        data = Customer.parser.parse_args()
        if CustomersModel.find_by_name(data['first_name']):
            return {'message':"customer whit that name already exists"},400
        customer = CustomersModel(data['first_name'],data['last_name'],data['address'],data['phone_no'],data['credit_card_no'],data['user_id'])
        customer.save_to_db()
        customer = CustomersModel.find_by_name(data['first_name']).json()
        return {'message':'create customer',"customer":customer},201

    @token_required
    def delete(self,id):

        new_name =  CustomersModel.find_by_id(id)
        if new_name:
            new_name.delete_from_db()
            return {'message':"Deleted"},200
        return {'message': 'Customer not found'},400

    @token_required
    def put(self,id):
        data = Customer.parser.parse_args()
        customer= CustomersModel.find_by_id(id)
        if customer:
            customer.first_name = data['first_name']
            customer.last_name = data['last_name']
            customer.address = data['address']
            customer.phone_no = data['phone_no']
            customer.credit_card_no = data['credit_card_no']
            customer.user_id = data['user_id']
            customer.Update()
            return {'message':"Customer update"},200
        return {'message':"Customer not exists"},400




class Customers(Resource):
    @token_required
    def get(self):
        customer = CustomersModel.query.all()
        return {'all':list(x.json() for x in customer)},200


class Customer_by(Resource):
    def get(self,id):
            customer = CustomersModel.find_by_user_id(id)
            if customer:
                return {'customer':customer.json() },200
            return {'message':"customer Not exist"},400
        