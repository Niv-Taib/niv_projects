
from flask_restful import Resource,reqparse
from models.Countries import CountriesModel
from Resource.security.user_login import  token_required

class Country(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, required=True, help='Every users must have a name') 

    @token_required
    def get(self,name):
        country = CountriesModel.find_by_name(name).json()
        if country:
            return {'Country':country},200
        return {'message': 'Country not found'},400
    @token_required
    def post(self):
        data = Country.parser.parse_args()
        country =  CountriesModel.find_by_name(data['name'])
        if country:
            return {'message':'Not create country'},400
        country = CountriesModel(data['name'])
        country.save_to_db()
        return {'message':'Create country'},201   

    @token_required
    def delete(self,name):
        country =  CountriesModel.find_by_name(name)
        if country:
            country.delete_from_db()
            return {'message':'Deleted'},200
        return {'message': 'Country not found'},404
    @token_required
    def put(self,name):
        data = Country.parser.parse_args()
        country =  CountriesModel.find_by_name(name)
        if country:
            country.name = data['name']
            country.Update()
            return {'message':'Update country'},201 
        return {'message': 'User not found'},400




class Countries(Resource):
    def get(self):
        country = CountriesModel.query.all()
        return {'Country':list(x.json() for x in country)},200