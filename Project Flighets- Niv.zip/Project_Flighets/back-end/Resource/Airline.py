
from flask_restful import Resource,reqparse
from models.Airline_Companies import Airline_Companies_Model
from Resource.security.user_login import  token_required
from models.Users import  UsersModel
class Airline(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument('name', type=str, required=True, help='Every users must have a name') 
    parser.add_argument('country_id', type=str, required=True, help='Country must have a name') 
    parser.add_argument('user_id', type=str, required=True, help='User must have a name') 

    @token_required
    def get(self,name):
        airline = Airline_Companies_Model.find_by_name(name)
        if airline:
            return {'Airline':airline.json()},200
        return {'message':"Airline not exists"},400
    
    @token_required
    def post(self):
        data = Airline.parser.parse_args()
        airline = Airline_Companies_Model.find_by_name(data['name'])
        user_id = Airline_Companies_Model.find_by_user_id(data['user_id'])
        if airline or user_id:
            return {'message':'Airline already exists'},400
        Airline_Companies_Model(data['name'],data['country_id'],data['user_id']).save_to_db()
        user = UsersModel.find_by_username(data['user_id'])
        if user:
            user.user_roles_id = 2
            user.Update()
        airline = Airline_Companies_Model.find_by_name(data['name']).json()
        return {'message':'Created airline',"airline":airline},201 
        

    @token_required
    def delete(self,name):
        airline =  Airline_Companies_Model.find_by_name(name)
        if airline:
            airline.delete_from_db()
            return {'message':'Deleted'},202
        return {'message': 'Airline not found'},400

    @token_required
    def put(self,name):
        data = Airline.parser.parse_args()
        airline = Airline_Companies_Model.find_by_name(name)
        user_id = Airline_Companies_Model.find_by_user_id(data['user_id'])
        if airline:
            if user_id:
                return {'message': 'Airline whit this user exists'},400 
            airline.name = data['name']
            airline.country_id = data['country_id']
            airline.user_id = data['user_id']
            airline.Update()
            return {'message': 'Airline Update'},200
        return {'message': 'Airline not found'},400


class Airlines(Resource):
    @token_required
    def get(self):
        airline = Airline_Companies_Model.query.all()
        return {'all':list(x.json() for x in airline)},200



class Airline_by_user_id(Resource):
    def get(self,user_id):
        airline = Airline_Companies_Model.find_by_user_id(user_id)
        if airline:
            return {'Airline':airline.json()},200
        return {'message':"Airline not exists"},400