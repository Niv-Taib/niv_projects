

from flask_restful import Resource,reqparse
from models.Users_Roles import User_RolesModel
from Resource.security.user_login import  token_required

class Users_Roles(Resource):
    
    parser = reqparse.RequestParser()
    parser.add_argument('user_roles', type=str, required=True, help='Every User must have a roles') 
    
    @token_required
    def get(self):
        user_roles = User_RolesModel.query.all()
        return {'all':list(x.json() for x in user_roles)},200

