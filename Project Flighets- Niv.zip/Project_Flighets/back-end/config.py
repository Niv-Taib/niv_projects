secret_key = '9369e88c98514177bc282cbc5e176a0d'
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQL = 'sqlite:///data.db'



