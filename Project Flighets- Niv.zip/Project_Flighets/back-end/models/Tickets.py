from db import db
class TicketsModel(db.Model):
    
    __tablename__ = 'Tickets'
    
    id = db.Column (db.Integer ,primary_key=True, autoincrement=True)
    flight_id = db.Column(db.Integer,db.ForeignKey('Flights.id'))
    customer_id = db.Column(db.Integer,db.ForeignKey('Customers.id'))
    flight = db.relationship('FlightsModel')
 
           
    def __init__(self,flight_id,customer_id):
            self.flight_id = flight_id
            self.customer_id = customer_id
            
    def json(self):
        return {'id':self.id,
                'flight_id': {'id':self.flight.id, 
                              'airline_company':self.flight.airline_company,
                              'origin_country':self.flight.origin_country,
                              'deistination_country':self.flight.deistination_country,
                              'departure_time':self.flight.departure_time,
                              'lending_time':self.flight.lending_time,
                              'remaining_tickets':self.flight.remaining_tickets,
                                            },
                'customer_id':self.customer_id
                 }
    

    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 

    @classmethod
    def find_by_customer_id(self,customer_id):
        return TicketsModel.query.filter_by(customer_id = customer_id).all()

    @classmethod
    def find_by_flight_id(self,flight_id):
        return TicketsModel.query.filter_by(flight_id = flight_id).first()

    @classmethod
    def find_by_id(self,id):
        return TicketsModel.query.filter_by(id = id).first() 
        

    def delete_from_db(self):
        db.session.delete(self)
        db.session.commit()
        
    def Update(self):
        db.session.commit() 
