from db import db


# 1 = Admin
# 2 = Air line
# 3 = User

class User_RolesModel(db.Model):
    __tablename__ = 'User_Roles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_roles = db.Column(db.String(250), unique=True)

   
    def __init__(self,user_roles):
        self.user_roles = user_roles
       
    def save_to_db(self):
        db.session.add(self)
        db.session.commit()  

    @classmethod
    def find_by_roles_name(self,roles):
        return  User_RolesModel.query.filter_by(user_roles = roles).first()

    @classmethod
    def find_by_id(self,id):
        return User_RolesModel.query.filter_by(id = id).first()
       

    def delete_from_db(self):
            db.session.delete(self)
            db.session.commit()

    def json(self):
        return {'id':self.id,'Roles': self.user_roles}