
from db import db

class CustomersModel(db.Model):
    
    __tablename__ = 'Customers'
    
    id = db.Column (db.Integer ,primary_key=True, autoincrement=True)
    first_name = db.Column(db.String(250))
    last_name = db.Column(db.String(250))
    address = db.Column(db.String(250))
    phone_no = db.Column(db.String(250),unique=True)
    credit_card_no = db.Column(db.String(250),unique=True)
    user_id = db.Column(db.Integer,db.ForeignKey('Users.id'),unique=True)

    users = db.relationship('UsersModel')
    
    def __init__(self,first_name,last_name,address,phone_no,credit_card_no,user_id):
            self.first_name = first_name
            self.last_name = last_name
            self.address = address
            self.phone_no = phone_no
            self.credit_card_no = credit_card_no
            self.user_id = user_id
            
    def json(self):
        return {'id':self.id,'first_name': self.first_name ,'last_name': self.last_name ,'address':self.address ,'phone_no': self.phone_no,'credit_card_no':self.credit_card_no, 'user_id': self.user_id }
    


    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 

    @classmethod
    def find_by_name(self,first_name):
        return  CustomersModel.query.filter_by(first_name = first_name).first()
    
    @classmethod
    def find_by_id(self,id):
        return  CustomersModel.query.filter_by(id = id).first()

    @classmethod
    def find_by_user_id(self,user_id):
        return  CustomersModel.query.filter_by(user_id = user_id).first()
           

    def delete_from_db(self):
        db.session.delete(self)
        db.session.commit()

    def Update(self):
        db.session.commit() 
