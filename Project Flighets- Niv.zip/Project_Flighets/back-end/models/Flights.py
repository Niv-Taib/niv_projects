
from db import db 


class FlightsModel(db.Model):
    
    __tablename__ = 'Flights'
    
    id = db.Column (db.Integer ,primary_key=True, autoincrement=True)
    airline_company = db.Column(db.String(250),db.ForeignKey('Airline_Companies.name'))
    origin_country = db.Column(db.String(250),db.ForeignKey('Countries.name'))
    deistination_country= db.Column(db.String(250),db.ForeignKey('Countries.name'))
    departure_time = db.Column(db.String(250))
    lending_time = db.Column(db.String(250))
    remaining_tickets = db.Column(db.String(250))

    def __init__(self,airline_company,origin_country,deistination_country,departure_time,lending_time,remaining_tickets):
            self.airline_company = airline_company
            self.origin_country = origin_country
            self.deistination_country = deistination_country
            self.departure_time = departure_time
            self.lending_time = lending_time
            self.remaining_tickets = remaining_tickets
            
    def json(self):
        return {'id':self.id
                ,'airline_company':self.airline_company 
                ,'origin_country':self.origin_country 
                ,'deistination_country':self.deistination_country
                ,'departure_time':self.departure_time
                ,'lending_time': self.lending_time
                ,'remaining_tickets':self.remaining_tickets}
    
 
    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 

    @classmethod
    def find_by_name(self,airline_company):
        return FlightsModel.query.filter_by(airline_company = airline_company).first()
        

    def delete_from_db(self):

        db.session.delete(self)
        db.session.commit()
        
    def Update(self):
        db.session.commit() 

           
    @classmethod
    def find_by_id(self,id):
        return FlightsModel.query.filter_by(id = id).first()
    
    @classmethod 
    def get_all(self):
        fligth = FlightsModel.query.all()
        return list(x.json() for x in fligth)
    
    
    
    
    
    
    
