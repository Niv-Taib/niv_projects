
from db import db 

class UsersModel(db.Model):

    __tablename__ = 'Users'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(250), unique=True)
    password = db.Column(db.String(250),nullable=False)
    email = db.Column(db.String(250), unique=True)
    user_roles_id = db.Column(db.Integer, db.ForeignKey('User_Roles.id'))
    User_Roles = db.relationship('User_RolesModel')

    def __init__(self,username,password,email,user_roles_id):
        
        self.username = username
        self.password = password
        self.email = email
        self.user_roles_id = user_roles_id

    def json(self):
        return {'id':self.id ,'username': self.username ,'email': self.email , 'user_roles_id':{'id':self.User_Roles.id,'roles':self.User_Roles.user_roles} }
    
    @classmethod
    def find_by_username(self,username):
        return UsersModel.query.filter_by(username = username).first()
       
    @classmethod
    def find_by_id(self,id):
        return UsersModel.query.filter_by(id = id).first()
       
    def delete_from_db(self):
        db.session.delete(self)
        db.session.commit() 
    
    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 

    def Update(self):
        db.session.commit() 

    
        
    @classmethod 
    def get_all(self):
        return UsersModel.query.all()
    
    @classmethod
    def update(self,username,password,email,user_roles_id):
        admin = UsersModel.find_by_name(username)
        if admin:
            return admin.json()
        else:
            UsersModel(username,password,email,user_roles_id).save_to_db()
            return f'create admin'