from db import db

class Airline_Companies_Model(db.Model):
    
    __tablename__ = 'Airline_Companies'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(250), unique=True )
    country_id = db.Column(db.String(250),db.ForeignKey('Countries.name'))
    user_id = db.Column(db.String(250), db.ForeignKey('Users.username'), unique=True )
    Ticket = db.relationship('FlightsModel', backref="Flights")
    
    
    def __init__(self,name,country_id,user_id):
            
        self.name = name
        self.country_id = country_id
        self.user_id = user_id
        

    def save_to_db(self):
        db.session.add(self)
        db.session.commit() 

    def delete_from_db(self):
            db.session.delete(self)
            db.session.commit()

    def json(self):
        return {'id':self.id,'name':  self.name  ,'country_id': self.country_id,'user_id': self.user_id }
    
    @classmethod
    def find_by_name(self,name):
        return Airline_Companies_Model.query.filter_by(name = name).first()

    @classmethod
    def find_by_id(self,id):
        return Airline_Companies_Model.query.filter_by(id = id).first()

    @classmethod  
    def find_by_user_id(self,id):
        return Airline_Companies_Model.query.filter_by(user_id = id).first()
        
    def Update(self):
        db.session.commit() 
